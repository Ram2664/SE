# Disaster Management App

## Overview

This is a Flutter application designed to assist users in managing disaster situations by providing essential functionalities like user authentication, information sharing, and real-time locations.

## Features

- User Login and Signup
- Password Recovery
- Important Facts and Messages about disaster management
- Integration with Google Maps for real-time tracking
- Chatbot for user assistance
- Send alert messages

## Setup Instructions

1. Ensure you have Flutter installed on your system. Follow the official installation guide: [Flutter Installation](https://flutter.dev/docs/get-started/install)
2. Clone this repository or download the source code.
   
   