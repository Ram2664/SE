import 'package:flutter/material.dart';

class InputField extends StatelessWidget {
  final String label;
  final bool isPassword;
  final Function(String) onChanged;
  final String? Function(String?)? validator;

  InputField({required this.label, required this.onChanged, this.isPassword = false, this.validator});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      decoration: InputDecoration(labelText: label),
      obscureText: isPassword,
      onChanged: onChanged,
      validator: validator,
    );
  }
}
