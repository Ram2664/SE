import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Home Page Dashboard'),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/map');
              },
              child: Text('Go to Map'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/facts_message');
              },
              child: Text('View Important Facts'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/send_message');
              },
              child: Text('Send Alert Message'),
            ),
          ],
        ),
      ),
    );
  }
}
