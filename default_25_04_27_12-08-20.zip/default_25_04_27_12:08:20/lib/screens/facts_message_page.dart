import 'package:flutter/material.dart';

class FactsMessagePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Important Facts')),
      body: Center(
        child: Text('This will display disaster management facts and messages.'),
      ),
    );
  }
}
