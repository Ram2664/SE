import 'package:flutter/material.dart';

class SendMessagePage extends StatefulWidget {
  @override
  _SendMessagePageState createState() => _SendMessagePageState();
}

class _SendMessagePageState extends State<SendMessagePage> {
  final _formKey = GlobalKey<FormState>();
  String message = '';
  String urgency = '';

  void _sendMessage() {
    if (_formKey.currentState!.validate()) {
      // Handle send message logic here
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Message Sent')));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Send Message')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Message'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a message';
                  }
                  return null;
                },
                onChanged: (value) {
                  message = value;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Urgency Level'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please specify the urgency level';
                  }
                  return null;
                },
                onChanged: (value) {
                  urgency = value;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _sendMessage,
                child: Text('Send Message'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
