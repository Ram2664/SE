import 'package:flutter/material.dart';

class DialogFlowPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Chatbot')),
      body: Center(
        child: Text('This will be the chatbot interface'),
      ),
    );
  }
}
