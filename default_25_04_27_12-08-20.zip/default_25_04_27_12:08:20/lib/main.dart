import 'package:flutter/material.dart';
import 'screens/login.dart';
import 'screens/signup.dart';
import 'screens/home_page.dart';
import 'screens/welcome_page.dart';
import 'screens/forgot_password.dart';
import 'screens/dialog_flow_page.dart';
import 'screens/facts_message_page.dart';
import 'screens/map_integration.dart';
import 'screens/send_message_page.dart';

void main() {
  runApp(DisasterManagementApp());
}

class DisasterManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Disaster Management App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(),
        '/signup': (context) => SignupPage(),
        '/welcome': (context) => WelcomePage(),
        '/home': (context) => HomePage(),
        '/forgot_password': (context) => ForgotPasswordPage(),
        '/dialog_flow': (context) => DialogFlowPage(),
        '/facts_message': (context) => FactsMessagePage(),
        '/map': (context) => MapIntegrationPage(),
        '/send_message': (context) => SendMessagePage(),
      },
    );
  }
}
